// بيقرأ رابط الباك إند من Environment Variable على Vercel اسمه BOT_API_URL
module.exports = (req, res) => {
  res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
  res.setHeader('Cache-Control', 'public, max-age=60');
  res.end('window.BOTNEST_API=' + JSON.stringify((process.env.BOT_API_URL || '').replace(/\/$/, '')) + ';');
};
