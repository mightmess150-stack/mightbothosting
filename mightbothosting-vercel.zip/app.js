/* MightBotHosting — طبقة الربط بالـ Backend + Contact + واجهة الدفع. بتتحمّل آخر حاجة وبتعدّل الدوال القديمة بدون ما تكسرها. */
(function(){
const API=window.BOTNEST_API||'';
const _oLogin=window.doLogin,_oReg=window.doReg;   // الوضع التجريبي القديم لو الباك إند مش متصل
const netErr=e=>e instanceof TypeError;           // لو الواجهة على دومين تاني: window.BOTNEST_API='https://api.example.com'
const $=id=>document.getElementById(id);
let TOKEN=localStorage.getItem('mbh_token')||'',es=null,BOTS=[],live=false;
const esc2=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function api(path,opt={}){
  const h={...(opt.body&&!(opt.body instanceof FormData)?{'Content-Type':'application/json'}:{}),...(TOKEN?{Authorization:'Bearer '+TOKEN}:{})};
  const r=await fetch(API+path,{...opt,headers:h,body:opt.body&&!(opt.body instanceof FormData)?JSON.stringify(opt.body):opt.body});
  const j=await r.json().catch(()=>({}));
  if(r.status===401&&TOKEN&&path!=='/api/login'){logout(true)}
  if(!r.ok)throw new Error(j.error||'حصل خطأ');
  return j;
}

/* ---------- الدخول والتسجيل (نفس الباسوورد بتاع الاستضافة) ---------- */
function authOk(d){TOKEN=d.token;localStorage.setItem('mbh_token',TOKEN);live=true;loginOk(d.user.name);loadBots()}
window.doLogin=async function(btn){
  const email=$('l-em').value.trim(),password=$('l-pw').value;
  if(!email||!password)return toast('⚠️ ادخل الإيميل وكلمة المرور','w');
  btn.disabled=true;btn.textContent='جاري الدخول...';
  try{authOk(await api('/api/login',{method:'POST',body:{email,password}}))}catch(e){if(netErr(e)||!API){toast('ℹ️ الباك إند مش متصل — وضع تجريبي');_oLogin(btn)}else toast('❌ '+e.message,'w')}
  btn.disabled=false;btn.textContent='تسجيل الدخول';
};
window.doReg=async function(btn){
  const name=$('r-fn').value.trim(),email=$('r-em').value.trim(),password=$('r-pw').value;
  if(!name||!email||!password)return toast('⚠️ ادخل كل البيانات','w');
  if(password.length<8)return toast('⚠️ كلمة المرور أقصر من 8 أحرف','w');
  btn.disabled=true;btn.textContent='جاري الإنشاء...';
  try{authOk(await api('/api/register',{method:'POST',body:{name,email,password}}))}catch(e){if(netErr(e)||!API){toast('ℹ️ الباك إند مش متصل — وضع تجريبي');_oReg(btn)}else toast('❌ '+e.message,'w')}
  btn.disabled=false;btn.textContent='إنشاء حساب مجاني';
};
window.dcLogin=()=>toast('🔗 الدخول بـ Discord هيتفعّل قريبًا — استخدم الإيميل حاليًا');
const _out=window.doOut;
function logout(silent){TOKEN='';localStorage.removeItem('mbh_token');live=false;if(es)es.close();if(!silent)_out();else{try{_out()}catch{}}}
window.doOut=()=>logout(false);

/* ---------- البوتات الحقيقية ---------- */
const stTxt={running:['🟢 شغّال','var(--ok)'],stopped:['⚫ متوقف','var(--muted)']};
async function loadBots(){
  try{BOTS=(await api('/api/bots')).bots}catch{return}
  const grid=document.querySelector('#tab-bots > div:nth-of-type(2)');if(!grid)return;
  grid.innerHTML=BOTS.map(b=>{const s=stTxt[b.status];return `<div style="background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px"><div><div style="font-weight:700">🤖 ${esc2(b.name)}</div><div style="font-size:.72rem;color:var(--muted)">${b.runtime==='python'?'Python':'Node.js'}</div></div><span style="font-size:.78rem;color:${s[1]}">${s[0]}</span></div>
    <div style="display:flex;gap:6px;flex-wrap:wrap">
      ${b.status==='running'?`<button class="btn berr bsm" onclick="bnAct('${b.id}','stop')">■ إيقاف</button><button class="btn bg bsm" onclick="bnAct('${b.id}','restart')">↻ إعادة</button>`:`<button class="btn bok bsm" onclick="bnAct('${b.id}','start')">▶ تشغيل</button>`}
      <button class="btn bg bsm" onclick="bnLogs('${b.id}','${esc2(b.name)}')">📜 لوجات</button>
      <button class="btn bg bsm" onclick="bnToken('${b.id}')">🔑 توكن</button>
      <button class="btn berr bsm" onclick="bnDel('${b.id}','${esc2(b.name)}')">🗑</button></div></div>`}).join('')
   +`<div onclick="openMod()" style="background:var(--card);border:2px dashed var(--border);border-radius:14px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:28px;cursor:pointer"><div style="font-size:1.8rem">➕</div><div style="font-weight:700;font-size:.9rem">Deploy بوت جديد</div></div>`;
}
window.bnAct=async(id,a)=>{try{await api(`/api/bots/${id}/${a}`,{method:'POST'});toast('✅ تم','ok')}catch(e){toast('❌ '+e.message,'w')}loadBots()};
window.bnDel=async(id,n)=>{if(!confirm('حذف '+n+' نهائيًا؟'))return;try{await api('/api/bots/'+id,{method:'DELETE'});toast('🗑 اتحذف')}catch(e){toast('❌ '+e.message,'w')}loadBots()};
window.bnToken=async id=>{const t=prompt('Discord Token الجديد:');if(!t)return;try{await api(`/api/bots/${id}/token`,{method:'POST',body:{token:t}});toast('🔑 اتحفظ — اعمل إعادة تشغيل','ok')}catch(e){toast('❌ '+e.message,'w')}};
window.stopBot=n=>{const b=BOTS.find(x=>x.name===n);if(b)bnAct(b.id,'stop')};
window.bnLogs=(id,name)=>{
  if(es)es.close();logLines=[];renderLogs();setTab('logs');
  es=new EventSource(`${API}/api/bots/${id}/logs?t=${encodeURIComponent(TOKEN)}`);
  es.onmessage=e=>{const l=JSON.parse(e.data);addLog(l.lvl==='err'?'err':l.lvl==='warn'?'warn':l.lvl==='ok'?'ok':'info',name,l.msg.trim())};
};
const _startLogs=window.startLogs;window.startLogs=function(){if(!live)_startLogs&&_startLogs()};  // الداتا الوهمية بس لو مفيش اتصال حقيقي

/* ---------- Deploy حقيقي ---------- */
const _setDTab=window.setDTab;let pickedFile=null;
window.onFile=inp=>{pickedFile=inp.files[0]||null;if(pickedFile)toast('📎 '+pickedFile.name)};
window.onDrop=e=>{e.preventDefault();pickedFile=e.dataTransfer.files[0]||null;if(pickedFile)toast('📎 '+pickedFile.name)};
window.doDeploy=async function(){
  if(!live){toast('سجّل دخول الأول','w');return}
  const wrap=$('dt-upload'),sel=wrap.querySelector('select'),tok=wrap.querySelector('input[type=password]');
  const fd=new FormData();fd.append('name',$('d-name').value.trim());fd.append('runtime',/Python/.test(sel.value)?'python':'node');fd.append('token',tok.value);
  if(pickedFile)fd.append('file',pickedFile);
  toast('🚀 جاري الرفع...','ok');
  try{await api('/api/bots',{method:'POST',body:fd});closeMod();toast('✅ اترفع واشتغل','ok');pickedFile=null;tok.value='';loadBots()}
  catch(e){toast('❌ '+e.message,'w')}
};

/* ---------- صفحة Contact ---------- */
document.body.insertAdjacentHTML('beforeend',`
<div id="pg-contact" style="display:none;min-height:100vh;padding:110px 20px 60px;position:relative;z-index:2">
 <div style="max-width:560px;margin:0 auto;background:var(--card);border:1px solid var(--border);border-radius:18px;padding:28px">
  <h2 style="margin-bottom:6px">📬 تواصل معانا</h2><p style="color:var(--muted);font-size:.88rem;margin-bottom:18px">عندك سؤال أو مشكلة؟ ابعتلنا ونرد عليك في أقرب وقت.</p>
  <div class="field"><label>الاسم</label><input id="c-n" maxlength="60"></div>
  <div class="field"><label>البريد الإلكتروني</label><input id="c-e" type="email"></div>
  <div class="field"><label>الموضوع</label><input id="c-s" maxlength="100"></div>
  <div class="field"><label>الرسالة</label><textarea id="c-m" rows="5" maxlength="3000" style="width:100%;background:var(--bg);border:1px solid var(--border);border-radius:10px;color:var(--text);padding:10px;font-family:inherit;resize:vertical"></textarea></div>
  <button class="sbtn" id="c-btn" onclick="sendContact(this)">إرسال</button>
  <div style="text-align:center;margin-top:14px"><a href="#" onclick="goHome();return false">← الرجوع للرئيسية</a></div>
 </div></div>`);
const _show=window.show;
window.show=function(id){_show(id==='pg-contact'?'pg-home':id);['pg-home','pg-auth','pg-dash','pg-contact'].forEach(p=>{const el=$(p);if(!el)return;if(id==='pg-contact')el.style.display=p==='pg-contact'?'block':'none'})};
window.goContact=()=>{show('pg-contact');scrollTo({top:0,behavior:'smooth'})};
window.sendContact=async btn=>{
  btn.disabled=true;
  try{await api('/api/contact',{method:'POST',body:{name:$('c-n').value,email:$('c-e').value,subject:$('c-s').value,message:$('c-m').value}});toast('✅ وصلتنا رسالتك','ok');['c-n','c-e','c-s','c-m'].forEach(i=>$(i).value='')}
  catch(e){toast(netErr(e)?'ℹ️ الباك إند مش متصل — الرسالة ما اتبعتتش':'❌ '+e.message,'w')}
  btn.disabled=false;
};
const nl=document.querySelector('.nlinks');if(nl)nl.insertAdjacentHTML('beforeend','<a href="#" onclick="goContact();return false">تواصل</a>');

/* ---------- واجهة الدفع (UI فقط — مفيش خصم فعلي) ---------- */
document.body.insertAdjacentHTML('beforeend',`
<div id="pay-modal" style="display:none;position:fixed;inset:0;z-index:900;background:rgba(0,0,0,.7);align-items:center;justify-content:center;padding:16px">
 <div style="background:var(--card);border:1px solid var(--border);border-radius:18px;padding:24px;width:100%;max-width:440px;max-height:92vh;overflow:auto">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px"><h3>💳 الترقية</h3><button class="btn bg bsm" onclick="closePay()">✕</button></div>
  <div id="pay-plans" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px"></div>
  <div id="pay-methods" style="display:flex;gap:6px;margin-bottom:14px;flex-wrap:wrap"></div>
  <div id="pay-card">
   <div class="field"><label>اسم حامل الكارت</label><input id="p-n"></div>
   <div class="field"><label>رقم الكارت</label><input id="p-c" inputmode="numeric" maxlength="19" placeholder="0000 0000 0000 0000" oninput="this.value=this.value.replace(/\\D/g,'').slice(0,16).replace(/(.{4})/g,'$1 ').trim()"></div>
   <div class="frow"><div class="field"><label>الانتهاء</label><input id="p-x" maxlength="5" placeholder="MM/YY" oninput="let v=this.value.replace(/\\D/g,'').slice(0,4);this.value=v.length>2?v.slice(0,2)+'/'+v.slice(2):v"></div>
   <div class="field"><label>CVC</label><input id="p-v" type="password" maxlength="4" inputmode="numeric"></div></div>
  </div>
  <div id="pay-alt" class="hidden" style="background:var(--bg);border-radius:10px;padding:14px;font-size:.85rem;color:var(--muted);margin-bottom:12px"></div>
  <button class="sbtn" onclick="paySubmit()">إتمام الدفع</button>
  <p style="font-size:.72rem;color:var(--muted);text-align:center;margin-top:10px">🔒 الدفع الإلكتروني لسه مش مفعّل — ده عرض للواجهة فقط ومفيش أي بيانات بتتخزن.</p>
 </div></div>`);
const PL=[['Pro','$9','10 بوتات + 512MB'],['Business','$29','بوتات أكتر + دعم']],PM=[['💳','كارت'],['📱','InstaPay'],['📞','Vodafone Cash'],['🅿️','PayPal']];
let plan=0,meth=0;
function drawPay(){
  $('pay-plans').innerHTML=PL.map((p,i)=>`<div onclick="plan_(${i})" style="cursor:pointer;border:1px solid ${i===plan?'var(--a)':'var(--border)'};background:${i===plan?'rgba(124,92,255,.08)':'transparent'};border-radius:12px;padding:12px;text-align:center"><b>${p[0]}</b><div style="font-size:1.3rem;font-weight:800">${p[1]}<small style="font-size:.7rem;color:var(--muted)">/شهر</small></div><div style="font-size:.72rem;color:var(--muted)">${p[2]}</div></div>`).join('');
  $('pay-methods').innerHTML=PM.map((m,i)=>`<button class="btn ${i===meth?'bp':'bg'} bsm" onclick="meth_(${i})">${m[0]} ${m[1]}</button>`).join('');
  $('pay-card').classList.toggle('hidden',meth!==0);$('pay-alt').classList.toggle('hidden',meth===0);
  $('pay-alt').textContent=meth===0?'':`هتتحوّل لصفحة ${PM[meth][1]} لإتمام العملية بعد تفعيل الدفع.`;
}
window.plan_=i=>{plan=i;drawPay()};window.meth_=i=>{meth=i;drawPay()};
window.openPay=()=>{drawPay();$('pay-modal').style.display='flex'};window.closePay=()=>$('pay-modal').style.display='none';
window.paySubmit=async()=>{
  if(meth===0){const c=$('p-c').value.replace(/\s/g,'');if(c.length<13||!$('p-n').value||!/^\d\d\/\d\d$/.test($('p-x').value))return toast('⚠️ راجع بيانات الكارت','w')}
  try{await api('/api/billing/checkout',{method:'POST',body:{plan:PL[plan][0]}})}catch(e){toast('ℹ️ '+e.message)}
};
const bb=document.querySelector('#tab-bill button.bp');if(bb)bb.onclick=openPay;

/* ---------- استرجاع الجلسة ---------- */
if(TOKEN)api('/api/me').then(d=>{live=true;loginOk(d.user.name);loadBots()}).catch(()=>{});
const _setTab=window.setTab;window.setTab=function(t){_setTab(t);if(t==='bots'&&live)loadBots()};
setInterval(()=>{if(live&&!$('tab-bots').classList.contains('hidden'))loadBots()},8000);
})();
