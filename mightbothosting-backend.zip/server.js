'use strict';
// MightBotHosting — Backend (Node.js + Express). تشغيل: npm i && node server.js
const express = require('express'), path = require('path'), fs = require('fs'), crypto = require('crypto');
const { spawn } = require('child_process');
const bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken'), multer = require('multer'), AdmZip = require('adm-zip');

const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, 'data'), BOTS = path.join(DATA, 'bots');
fs.mkdirSync(BOTS, { recursive: true });
let SECRET = process.env.JWT_SECRET;
if (!SECRET) { // نولّد سر ثابت أول مرة ونحفظه
  const f = path.join(DATA, '.secret');
  SECRET = fs.existsSync(f) ? fs.readFileSync(f, 'utf8') : crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(f, SECRET, { mode: 0o600 });
}
const KEY = crypto.createHash('sha256').update(SECRET).digest();
const PLANS = { free: { bots: 2, mem: 128 }, pro: { bots: 10, mem: 512 } };

/* ---------- تخزين JSON بسيط (كتابة ذرّية) ---------- */
const DB_FILE = path.join(DATA, 'db.json');
const db = fs.existsSync(DB_FILE) ? JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) : { users: [], bots: [], contacts: [] };
const save = () => { fs.writeFileSync(DB_FILE + '.tmp', JSON.stringify(db)); fs.renameSync(DB_FILE + '.tmp', DB_FILE); };
const uid = () => crypto.randomBytes(8).toString('hex');
const enc = t => { const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', KEY, iv); const e = Buffer.concat([c.update(t, 'utf8'), c.final()]); return [iv, c.getAuthTag(), e].map(b => b.toString('base64')).join('.'); };
const dec = s => { const [iv, tag, e] = s.split('.').map(x => Buffer.from(x, 'base64')); const d = crypto.createDecipheriv('aes-256-gcm', KEY, iv); d.setAuthTag(tag); return Buffer.concat([d.update(e), d.final()]).toString('utf8'); };

/* ---------- Rate limit بسيط ---------- */
const hits = new Map();
const limit = (n, ms) => (req, res, next) => {
  const k = req.ip + req.path, now = Date.now(), a = (hits.get(k) || []).filter(t => now - t < ms);
  if (a.length >= n) return res.status(429).json({ error: 'محاولات كتير، جرّب بعد شوية' });
  a.push(now); hits.set(k, a); next();
};

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '100kb' }));
app.use((req, res, next) => {
  const list = (process.env.CORS_ORIGIN || '').split(',').map(x => x.trim()).filter(Boolean), o = list.includes(req.headers.origin) ? req.headers.origin : '';
  if (o) { res.set({ 'Access-Control-Allow-Origin': o, Vary: 'Origin', 'Access-Control-Allow-Headers': 'Content-Type,Authorization', 'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS' }); if (req.method === 'OPTIONS') return res.sendStatus(204); }
  res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY' }); next();
});

/* ---------- Auth ---------- */
const sign = u => jwt.sign({ id: u.id }, SECRET, { expiresIn: '7d' });
const pub = u => ({ id: u.id, name: u.name, email: u.email, plan: u.plan });
function auth(req, res, next) {
  const t = (req.headers.authorization || '').replace('Bearer ', '') || req.query.t;
  try { const p = jwt.verify(t, SECRET); req.user = db.users.find(u => u.id === p.id); if (!req.user) throw 0; next(); }
  catch { res.status(401).json({ error: 'سجّل دخول الأول' }); }
}
const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
app.post('/api/register', limit(10, 3600e3), async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !emailRe.test(email || '')) return res.status(400).json({ error: 'بيانات غير صحيحة' });
  if (!password || password.length < 8) return res.status(400).json({ error: 'كلمة المرور أقصر من 8 أحرف' });
  const e = email.toLowerCase();
  if (db.users.some(u => u.email === e)) return res.status(409).json({ error: 'الإيميل مسجّل قبل كده' });
  const u = { id: uid(), name: String(name).slice(0, 40), email: e, hash: await bcrypt.hash(password, 11), plan: 'free', created: Date.now() };
  db.users.push(u); save(); res.json({ token: sign(u), user: pub(u) });
});
app.post('/api/login', limit(15, 900e3), async (req, res) => {
  const { email, password } = req.body || {};
  const u = db.users.find(x => x.email === String(email || '').toLowerCase());
  if (!u || !(await bcrypt.compare(String(password || ''), u.hash))) return res.status(401).json({ error: 'الإيميل أو كلمة المرور غلط' });
  res.json({ token: sign(u), user: pub(u) });
});
app.get('/api/me', auth, (req, res) => res.json({ user: pub(req.user), limits: PLANS[req.user.plan] }));

/* ---------- تشغيل البوتات ---------- */
const procs = new Map(); // botId -> { child, logs[], clients:Set }
const botDir = b => path.join(BOTS, b.owner, b.id);
const rt = id => procs.get(id) || procs.set(id, { child: null, logs: [], clients: new Set() }).get(id);
function log(id, lvl, msg) {
  const r = rt(id), l = { t: Date.now(), lvl, msg: String(msg).slice(0, 2000) };
  r.logs.push(l); if (r.logs.length > 500) r.logs.shift();
  r.clients.forEach(c => c.write(`data: ${JSON.stringify(l)}\n\n`));
}
const view = b => ({ id: b.id, name: b.name, runtime: b.runtime, status: procs.get(b.id)?.child ? 'running' : 'stopped', created: b.created, startedAt: procs.get(b.id)?.startedAt || null });
function entryOf(dir, runtime) {
  if (runtime === 'python') return ['python3', ['main.py']];
  let main = 'index.js';
  try { main = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')).main || main; } catch {}
  return ['node', [path.resolve(dir, main).startsWith(path.resolve(dir)) ? main : 'index.js']];
}
function run(cmd, args, opts, id) {
  return new Promise(ok => {
    const c = spawn(cmd, args, opts);
    c.stdout.on('data', d => log(id, 'info', d)); c.stderr.on('data', d => log(id, 'warn', d));
    c.on('error', e => { log(id, 'err', e.message); ok(1); }); c.on('close', ok);
  });
}
async function startBot(b, owner) {
  const r = rt(b.id); if (r.child || r.starting) return;
  r.starting = true;
  const dir = botDir(b), mem = PLANS[owner.plan].mem;
  try {
    if (b.runtime === 'node' && fs.existsSync(path.join(dir, 'package.json')) && !fs.existsSync(path.join(dir, 'node_modules'))) {
      log(b.id, 'info', '📦 npm install ...');
      await run('npm', ['install', '--omit=dev', '--ignore-scripts', '--no-audit', '--no-fund'], { cwd: dir }, b.id);
    }
    const [cmd, args] = entryOf(dir, b.runtime);
    const a = cmd === 'node' ? [`--max-old-space-size=${mem}`, ...args] : args;
    const env = { PATH: process.env.PATH, HOME: dir, NODE_ENV: 'production', ...(b.token ? { DISCORD_TOKEN: dec(b.token), TOKEN: dec(b.token) } : {}) };
    const c = spawn(cmd, a, { cwd: dir, env });
    r.child = c; r.startedAt = Date.now(); log(b.id, 'ok', '✅ البوت اشتغل');
    c.stdout.on('data', d => log(b.id, 'info', d)); c.stderr.on('data', d => log(b.id, 'err', d));
    c.on('error', e => log(b.id, 'err', e.message));
    c.on('close', code => { r.child = null; r.startedAt = null; log(b.id, code ? 'err' : 'warn', `⏹ البوت وقف (code ${code})`); });
  } finally { r.starting = false; }
}
const stopBot = id => new Promise(ok => {
  const c = procs.get(id)?.child; if (!c) return ok();
  const t = setTimeout(() => c.kill('SIGKILL'), 5000); c.once('close', () => { clearTimeout(t); ok(); }); c.kill('SIGTERM');
});

const upload = multer({ dest: path.join(DATA, 'tmp'), limits: { fileSize: 25 * 1024 * 1024 } });
const mine = (req, res, next) => { const b = db.bots.find(x => x.id === req.params.id && x.owner === req.user.id); if (!b) return res.status(404).json({ error: 'البوت مش موجود' }); req.bot = b; next(); };
const safeName = n => String(n || '').replace(/[^\w\u0600-\u06FF .-]/g, '').trim().slice(0, 32);

app.get('/api/bots', auth, (req, res) => res.json({ bots: db.bots.filter(b => b.owner === req.user.id).map(view) }));

app.post('/api/bots', auth, upload.single('file'), (req, res) => {
  const tmp = req.file?.path, clean = () => tmp && fs.rm(tmp, { force: true }, () => {});
  const name = safeName(req.body.name), runtime = req.body.runtime === 'python' ? 'python' : 'node';
  if (!name) { clean(); return res.status(400).json({ error: 'اكتب اسم البوت' }); }
  if (db.bots.filter(b => b.owner === req.user.id).length >= PLANS[req.user.plan].bots) { clean(); return res.status(403).json({ error: 'وصلت للحد الأقصى للبوتات في باقتك' }); }
  if (!req.file) return res.status(400).json({ error: 'ارفع ملف zip أو .js' });
  const b = { id: uid(), owner: req.user.id, name, runtime, created: Date.now(), token: req.body.token ? enc(req.body.token) : null };
  const dir = botDir(b); fs.mkdirSync(dir, { recursive: true });
  try {
    const orig = (req.file.originalname || '').toLowerCase();
    if (orig.endsWith('.zip')) {
      const zip = new AdmZip(tmp); let total = 0;
      for (const e of zip.getEntries()) {
        const out = path.resolve(dir, e.entryName);
        if (!out.startsWith(path.resolve(dir) + path.sep)) throw new Error('ملف zip غير آمن');   // حماية Zip-Slip
        if (e.entryName.includes('node_modules/') || e.entryName.startsWith('.')) continue;
        total += e.header.size; if (total > 100 * 1024 * 1024) throw new Error('حجم الملفات بعد الفك كبير جدًا');
        if (e.isDirectory) fs.mkdirSync(out, { recursive: true });
        else { fs.mkdirSync(path.dirname(out), { recursive: true }); fs.writeFileSync(out, e.getData()); }
      }
    } else if (orig.endsWith('.js') || orig.endsWith('.py')) fs.copyFileSync(tmp, path.join(dir, orig.endsWith('.py') ? 'main.py' : 'index.js'));
    else throw new Error('الصيغة المدعومة: zip أو js أو py');
  } catch (e) { fs.rmSync(dir, { recursive: true, force: true }); clean(); return res.status(400).json({ error: e.message }); }
  clean(); db.bots.push(b); save(); log(b.id, 'ok', '🚀 تم رفع البوت');
  startBot(b, req.user).catch(e => log(b.id, 'err', e.message));
  res.json({ bot: view(b) });
});
app.post('/api/bots/:id/start', auth, mine, async (req, res) => { await startBot(req.bot, req.user); res.json({ bot: view(req.bot) }); });
app.post('/api/bots/:id/stop', auth, mine, async (req, res) => { await stopBot(req.bot.id); log(req.bot.id, 'warn', '■ تم الإيقاف'); res.json({ bot: view(req.bot) }); });
app.post('/api/bots/:id/restart', auth, mine, async (req, res) => { await stopBot(req.bot.id); await startBot(req.bot, req.user); res.json({ bot: view(req.bot) }); });
app.post('/api/bots/:id/token', auth, mine, (req, res) => { if (!req.body.token) return res.status(400).json({ error: 'التوكن فاضي' }); req.bot.token = enc(String(req.body.token)); save(); res.json({ ok: true }); });
app.delete('/api/bots/:id', auth, mine, async (req, res) => {
  await stopBot(req.bot.id); fs.rmSync(botDir(req.bot), { recursive: true, force: true });
  db.bots = db.bots.filter(b => b !== req.bot); procs.delete(req.bot.id); save(); res.json({ ok: true });
});
app.get('/api/bots/:id/logs', auth, mine, (req, res) => {   // Server-Sent Events
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' }); res.flushHeaders();
  const r = rt(req.bot.id); r.logs.forEach(l => res.write(`data: ${JSON.stringify(l)}\n\n`));
  r.clients.add(res); const ka = setInterval(() => res.write(': ka\n\n'), 25000);
  req.on('close', () => { clearInterval(ka); r.clients.delete(res); });
});

/* ---------- Contact ---------- */
app.post('/api/contact', limit(5, 3600e3), (req, res) => {
  const { name, email, subject, message } = req.body || {};
  if (!name || !emailRe.test(email || '') || !message || message.length < 10) return res.status(400).json({ error: 'كمّل البيانات (الرسالة 10 أحرف على الأقل)' });
  db.contacts.push({ id: uid(), name: String(name).slice(0, 60), email, subject: String(subject || '').slice(0, 100), message: String(message).slice(0, 3000), at: Date.now() });
  save(); res.json({ ok: true });
});

/* ---------- Billing: واجهة فقط حاليًا ---------- */
app.post('/api/billing/checkout', auth, (req, res) => res.status(501).json({ error: 'الدفع الإلكتروني لسه مش متفعّل — هيتفعّل قريبًا' }));

/* ---------- الواجهة ---------- */
app.use('/api', (req, res) => res.status(404).json({ error: 'غير موجود' }));
app.get('/', (req, res) => res.json({ service: 'MightBotHosting API', ok: true }));
app.listen(PORT, () => console.log(`MightBotHosting شغّال على http://localhost:${PORT}`));

// إعادة تشغيل البوتات اللي كانت شغّالة مش مطلوب هنا؛ كل بوت بيتشغّل بزر Start.
process.on('SIGTERM', async () => { for (const id of procs.keys()) await stopBot(id); process.exit(0); });
